# Assessment of the soft-mode reinterpretation

**Date:** 25 September 2026.  
**Repository read:** `lrspeiser/photon-graviton`, main `67075c2c59dbe3c7cf55af4eb1d9747bcf000ffb`.

## Scope

These are independent arithmetic and exact constant-velocity source checks of the proposed
"Soft Gravitational Dressing / Bright Mode" interpretation. They do not simulate a gravitational
receiver, derive a metric, run the astronomical suite, or establish a new force.

The square-root table is numerically correct as a transformation of the saved **specific leakage**
ratios. It is not evidence that actual test bodies accelerate by that amount.

## Repository evidence inspected through the native connector

- `research_work/results/hot-companion/code/stream_store_v16.py`
- `research_work/results/hot-companion/run-stream-store-v16/stream_store_v16.json`
- `research_work/results/hot-companion/regression/candidates/no_hold.json`
- `research_work/results/hot-companion/code/blocker_release_v19.py`

All were pinned to the commit above. Source-value arrays in `sanity_checks.py` are transcribed
from the read JSON; the calculation does not require internet access.

## Specific leakage is not luminosity

The round-16 code averages, per cell,

    integral P(t) dt / integral E(t) dt,

and then averages these ratios across cells. It does not report the average total luminosity
of a collection with fixed equal initial stores.

For each freely moving case, velocities and the imposed relative-velocity mixing are constant.
The three bright-mode coordinates therefore reduce exactly to a single coordinate parallel
to the fixed mixing vector:

    Ddot = -delta y
    ydot = delta D - y
    E = D^2 + y^2
    P = 2 y^2
    Edot = -P

The exact solution is used to compute both observables with the same seeds, initial unit store,
and [10,60] model-time averaging window as the source script.

| sigma/u | Saved specific-leakage ratio | Exact continuous-time specific ratio | Actual time-averaged power ratio |
|---:|---:|---:|---:|
| 0.25 | 1.162177 | 1.162176 | 1.159269 |
| 0.5 | 1.696343 | 1.696339 | 1.680186 |
| 1 | 3.881636 | 3.881594 | 3.746459 |
| 2 | 12.735421 | 12.734889 | 11.149186 |
| 4 | 48.631273 | 48.623084 | 30.298227 |
| 8 | 197.825358 | 197.683883 | 48.468974 |

The small difference between saved and exact specific rates is distinct from the large
specific-rate/luminosity difference: the saved sums use pre-step power with post-step energy;
our integrals evaluate both at coincident times. This audit does not reproduce the RK4
discretization; it solves the constant-mixing continuum equations.

At sigma/u=8, mean remaining energy at t=60 is 0.2620 of the initial store, versus 0.9884
in the cold case. Weaker mixing, shorter measurement intervals after transients, or a
physically replenished reservoir could change the depletion. None is automatically excluded.
The result means that this saved run is not already a fixed-mass source-to-force verification
across the stated speed range.

## Validation actually performed

- 160-node versus 320-node Gauss integration differs by at most 1.44e-16 in the measured quantities.
- Exact source solution versus an independent matrix exponential differs by at most 2.45e-15.
- Integrated radiated power agrees with lost internal energy to better than 4.5e-14 absolute.
- No test evaluates a gravitational force; square roots are explicitly marked postprocessing.

See `results.json` for the exact metrics. The numerical checks are post-run consistency checks,
not preregistered evidence for a new physical theory.

## Meaning of the proposed force postulate

The assumptions

    epsilon_B = B^2/(8 pi G)
    acceleration = B
    outward energy current = u epsilon_B

produce the stated spherical mass/distance scaling. They do not derive the sign, vector
direction, source backreaction, or a nonzero mean acceleration from an oscillatory field.

The historical notebook already postulated the first two relationships. Naming B a soft
gravitational field is a potentially useful effective-theory interpretation, not an
independent receiver experiment.

A minimal scalar example demonstrates what must be added, without ruling out all alternatives:

    L = [dot(Phi)^2/u^2 - |grad Phi|^2]/(8 pi G) - rho Phi + L_kinetic
    acceleration = -grad Phi
    lap(Phi) - ddot(Phi)/u^2 = 4 pi G rho

This has a conventional phase-free static force from its local matter coupling, but its
static exterior acceleration is GM/r^2, not sqrt(GMa)/r. Its static outward energy flux is zero.
A propagating oscillation can have amplitude 1/r without giving a 1/r time-averaged acceleration.
Additional fields, nonlinear response, transport, or a demonstrable rectification mechanism
are needed for the proposed combination. This example is not the proposed completed action.

## External hold and screening

The saved `no_hold.json` explicitly sets both external pull and external heat to zero for a
separate system, and changes the release length to 200,000 AU (~0.970 pc). The old claimed
64/9/3 result totals 76 checks; the current 59/11/7 totals 77. Both candidates require a
matched current rerun before claiming a new improvement.

A falling coordinate system can remove a uniform metric acceleration locally, but does not
automatically remove an additional medium's state or energy density. The appropriate
symmetry, local invariant, and boundary response have to be defined in the completed theory.

If a blocker fraction R reduces emitted power, the proposed amplitude response is reduced by
sqrt(R), not R. Recovering the existing multiplicative force factor instead requires a
different specified coupling. Local equilibrium blocking and transported launch preparation
also imply different histories and should not be silently interchanged.

## Lifetime versus frequency

The proposed L=0.14544 pc and u=169.44 km/s yield tau=839.29 yr and hbar/tau=2.4851e-26 eV.
These are correct conversions. A relaxation time alone sets neither a carrier frequency,
a particle mass, nor an ultraviolet cutoff. Propagation and high-energy emission constraints
require the actual dispersion and coupling functions.

## Recommended comparison

1. Prioritize a local, phase-insensitive field/action construction as an effective-theory candidate.
2. Keep the round-16 source as a conditional leakage model; measure actual luminosity and store depletion.
3. Keep the derived conservative energy-shift medium as a force-and-conservation control, while recognizing
   its established linear-range limitations.
4. Run local/invariant screening as a separate empirical candidate, with the same current suite and
   a two-by-two separation of external-hold and release-length changes.
5. Require mean attraction, vector/spatial response, source-and-receiver energy/momentum exchange and
   source-mass scaling before describing the phase-free coupling as a demonstrated mechanism.

No repository files, constants, forecasts or adopted fits were changed.

## Reproduce

Python with NumPy and SciPy:

    python sanity_checks.py --output fresh_results.json

The script refuses to overwrite its requested output. `results.json` records one actual run.
