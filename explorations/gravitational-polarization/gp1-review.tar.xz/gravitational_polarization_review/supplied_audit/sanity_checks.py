"""Independent checks of the proposed soft-mode reinterpretation.
No receiver dynamics, field theory, or astronomical fit is computed.
Source: stream_store_v16.py and stream_store_v16.json at GitHub commit
67075c2c59dbe3c7cf55af4eb1d9747bcf000ffb, lrspeiser/photon-graviton.
The saved numbers below are transcribed from the native GitHub read.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from scipy.special import roots_legendre
from scipy.linalg import expm

COMMIT="67075c2c59dbe3c7cf55af4eb1d9747bcf000ffb"
R=np.array([.25,.5,1.,2.,4.,8.])
SAVED=np.array([1.1621769933503223,1.6963434612632862,3.8816355651778722,
                12.735421132122111,48.63127273180633,197.82535774826016])
ERR=np.array([.01575839216139565,.04458900840219329,.1521072965936787,
              .5759722412782856,2.295310344319229,9.87033125280025])

def state(delta: np.ndarray, t: np.ndarray) -> tuple[np.ndarray,np.ndarray]:
    """Exact constant-velocity reduction of D and the parallel bright mode.
    Ddot=-delta*y; ydot=delta*D-y; D(0)=1,y(0)=0.
    For the tested seeds every delta is below 1/2, away from critical damping.
    """
    delta=np.atleast_1d(np.asarray(delta,float)); t=np.atleast_1d(t)
    if np.any(delta>=.5) or np.any(delta<0):
        raise ValueError("This verification uses only 0 <= delta < 1/2.")
    disc=np.sqrt(1-4*delta**2)
    rp=(-1+disc)/2; rm=(-1-disc)/2
    ep=np.exp(rp[:,None]*t[None,:]); em=np.exp(rm[:,None]*t[None,:])
    D=(-rm[:,None]*ep+rp[:,None]*em)/disc[:,None]
    y=delta[:,None]*(ep-em)/disc[:,None]
    return D,y

def measure(r: float, order: int) -> dict:
    # Same legacy Gaussian draws as the free-motion code (seeds 1..8,64 cells).
    velocity=np.concatenate([
        np.random.RandomState(s).normal(0,r*.01,(64,3))
        for s in range(1,9)])
    velocity[:,2]-=.01
    delta=np.linalg.norm(velocity,axis=1)
    x,w=roots_legendre(order); t=10+25*(x+1); w=25*w
    D,y=state(delta,t); E=D**2+y**2; P=2*y**2
    e_integral=E@w; p_integral=P@w
    Dedge,yedge=state(delta,np.array([10.,60.]))
    Eedge=Dedge**2+yedge**2
    return {
        "sigma_over_u":r,
        "mean_specific_leak":float(np.mean(p_integral/e_integral)),
        "mean_absolute_power":float(np.mean(p_integral)/50),
        "mean_energy_at_60":float(np.mean(Eedge[:,1])),
        "energy_ledger_max_abs":float(np.max(np.abs(
            p_integral-(Eedge[:,0]-Eedge[:,1])))),
        "max_detuning":float(np.max(delta))
    }

def run()->dict:
    rows=[measure(float(r),160) for r in [0,*R]]
    fine=[measure(float(r),320) for r in [0,*R]]
    largest_quad_diff=max(abs(a[k]-b[k]) for a,b in zip(rows,fine)
                         for k in ("mean_specific_leak","mean_absolute_power",
                                   "mean_energy_at_60"))
    oracle=0.
    for delta in (.0,.01,.08,.30):
        for t in (0.,1.,10.,60.):
            exact=expm(np.array([[0.,-delta],[delta,-1.]])*t)@np.array([1.,0.])
            D,y=state(np.array([delta]),np.array([t]))
            oracle=max(oracle,float(np.max(np.abs(exact-np.array([D[0,0],y[0,0]])))))
    mapped=[]
    for r,p,e in zip(R,SAVED,ERR):
        q=np.sqrt(p); target=np.sqrt(1+3*r*r)
        mapped.append({"sigma_over_u":float(r),"saved_specific_ratio":float(p),
                       "sqrt_saved_ratio":float(q),"sqrt_standard_error_linearized":float(e/(2*q)),
                       "sqrt_law":float(target),
                       "sqrt_fractional_difference":float(q/target-1)})
    cold=fine[0]
    for row in fine:
        row["specific_ratio"]=row["mean_specific_leak"]/cold["mean_specific_leak"]
        row["absolute_power_ratio"]=row["mean_absolute_power"]/cold["mean_absolute_power"]
    for row,saved in zip(fine[1:],SAVED):
        row["difference_from_saved_specific_fraction"]=row["specific_ratio"]/saved-1
    tau=.14544*3.085677581491367e16/169440.
    assert oracle<1e-12
    assert largest_quad_diff<1e-12
    assert max(row["energy_ledger_max_abs"] for row in fine)<1e-12
    return {
        "scope":"Postprocessing and exact constant-velocity source audit; not a force simulation.",
        "commit":COMMIT,
        "source_folder":"research_work/results/hot-companion/",
        "setup":{"U":.01,"gamma":1.,"seeds":list(range(1,9)),
                 "cells_per_seed":64,"initial_energy_per_cell":1.,
                 "averaging_window":[10.,60.]},
        "saved_specific_leak_square_root":mapped,
        "exact_source_rows":fine,
        "validation":{"quadrature_max_abs_difference":largest_quad_diff,
                      "matrix_exponential_max_abs_difference":oracle},
        "timescale":{"L_pc":.14544,"u_kms":169.44,"tau_seconds":tau,
                     "tau_years":tau/31557600,
                     "hbar_over_tau_eV":6.582119569e-16/tau},
        "notes":[
          "Saved code averages each cell's integral(P)/integral(E), not total source luminosity.",
          "Exact-source mean_absolute_power is average P over the same cells and time window at equal initial E.",
          "For nu=0 the prescribed velocities and detunings are constant; three bright components reduce exactly to one.",
          "Saved RK4 uses pre-step P and post-step E in its sums. This audit uses coincident continuous-time integrals.",
          "The largest saved/exact specific-ratio discrepancy is about 0.072%; the specific-vs-absolute distinction is much larger.",
          "At high speed, finite depletion and variation among cells reduce actual luminosity. This does not exclude a weaker-depletion regime.",
          "Neither square-root postprocessing nor this source calculation produces a receiver acceleration.",
          "No field equation, backreaction, actual spatial motion, cosmic-ray loss, or astronomical suite is evaluated."
        ]
    }

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--output",type=Path,required=True)
    args=ap.parse_args()
    if args.output.exists(): raise SystemExit("Refusing to overwrite existing result.")
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(run(),indent=2)+"\n")
