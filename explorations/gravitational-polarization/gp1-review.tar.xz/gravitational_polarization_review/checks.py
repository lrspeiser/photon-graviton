#!/usr/bin/env python3
"""Independent tests of the gravity-current / polarization proposal.

These are model-unit diagnostics, not galaxy fits or a completed gravitational theory.
All assumptions and unsupported identifications are enumerated in REPORT.md.
Run: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python checks.py --output results.json
"""
from __future__ import annotations
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[v]='1'
import argparse, hashlib, json, math, platform, time
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.linalg import solve_continuous_lyapunov
from scipy.optimize import brentq

COMMIT='45f0a3ee04fdf0c6ca96ec8d10bb8195f488244b'
A_SI=6.297889390049439e-11
GD_SI=2.027287915237577e-10
U_SI=169443.3686899687
ELL=A_SI*U_SI/2
G_SI=6.67430e-11
C_SI=299792458.
AU=149597870700.
YEAR=31557600.


def heat_filter() -> dict:
    """Independent stationary covariance solve vs analytical filtered-velocity formula.
    v is OU, with prescribed correlation rate nu. qdot=(v-q) in units gamma=u=1.
    A covariance solution is exact for this specified linear model, not proof of its ontology.
    """
    rows=[]
    rng=np.random.default_rng(20260925)
    for nu in (.01,.1,1.,3.,10.,30.,100.):
        A=np.array([[-nu,0.],[1.,-1.]])
        D=np.array([[2*nu,0.],[0.,0.]])
        S=solve_continuous_lyapunov(A,-D)
        expected=1/(1+nu)
        samples=rng.multivariate_normal([0.,0.],S,size=(50000,3))
        q2=(samples[:,:,1]**2).sum(1)
        se=q2.std(ddof=1)/np.sqrt(len(q2))
        rows.append(dict(nu_over_gamma=nu,covariance_q_variance=float(S[1,1]),
                         exact_q_variance=expected,three_dimensional_mean=float(q2.mean()),
                         three_dimensional_expected=3*expected,standard_error=float(se),
                         z=float((q2.mean()-3*expected)/se)))
    harmonic=[]
    for omega in (.1,1.,3.,10.):
        # 60 units burn then 20 whole drive periods: direct deterministic time evolution.
        start=60.; duration=20*2*np.pi/omega
        t=np.linspace(start,start+duration,10001)
        sol=solve_ivp(lambda t,y:[-y[0]+np.sqrt(2)*np.cos(omega*t)],
                      [0.,t[-1]],[0.],t_eval=t,rtol=2e-10,atol=2e-12,
                      max_step=min(.2,.1/omega))
        measured=np.trapezoid(sol.y[0]**2,t)/duration
        exact=1/(1+omega**2)
        harmonic.append(dict(omega_over_gamma=omega,measured=float(measured),expected=exact,
                             fractional_error=float(measured/exact-1)))
    gyro=[]
    for nu in (0.,.01,1.,100.):
        om=1e6
        # Isotropic velocity, two gyrating components and one parallel component.
        fpar=1/(1+nu); fperp=(1+nu)/((1+nu)**2+om**2)
        gyro.append(dict(nu_over_gamma=nu,omega_over_gamma=om,
                         heat_fraction_of_unfiltered=float((fpar+2*fperp)/3)))
    return dict(ou=rows,harmonic=harmonic,gyromotion=gyro,
        covariance_max_error=max(abs(x['covariance_q_variance']-x['exact_q_variance']) for x in rows),
        max_abs_sampling_z=max(abs(x['z']) for x in rows),
        harmonic_max_fractional_error=max(abs(x['fractional_error']) for x in harmonic),
        scope='The q filter is assumed; covariance and its spectral consequences are calculated.')


def nonlinear_polarization() -> dict:
    """The proposed cubic damping softens growth, but does not impose a finite cap.
    Compare it with a truly bounded, separately postulated response, on Maxwell velocities.
    """
    qs=np.sqrt(65.6)
    def qc(w):
        return qs*2/np.sqrt(3)*np.sinh(np.arcsinh(3*np.sqrt(3)*w/(2*qs))/3)
    def qb(w):
        x=w/qs
        return qs*(2*x)/(1+np.sqrt(1+4*x*x))
    def moment(sigma,fn):
        return quad(lambda z: np.sqrt(2/np.pi)*z*z*np.exp(-z*z/2)*fn(sigma*z)**2,
                    0,15,epsabs=1e-9,epsrel=2e-10)[0]
    rows=[]
    for k in (0.03,.3,3.,12.,48.,100.,192.,1e4,1e8):
        sigma=np.sqrt(k/3)
        rows.append(dict(k=k,cubic_damping_heat=moment(sigma,qc),bounded_heat=moment(sigma,qb)))
    sig=np.geomspace(1e4,1e7,50)
    cubic=np.array([moment(s,qc) for s in sig])
    exponent=np.polyfit(np.log(sig),np.log(cubic),1)[0]
    return dict(qs_squared=qs**2,rows=rows,large_speed_heat_exponent=float(exponent),
        analytical_large_speed_exponent=2/3,
        scope='65.6 is an illustrative scale inherited from the earlier discussion, NOT a physical calibration or astronomical fit.')


def source_reciprocity() -> dict:
    # Conservative deep-AQUAL pair law used only as a reference for active charges Q=mW.
    rows=[]
    for W in (1.,5.18,68.,106.):
        Q1,Q2=1.,W
        F=(2/3)*((Q1+Q2)**1.5-Q1**1.5-Q2**1.5)
        # If sources carry Q but passive force is m*g rather than Q*g:
        bad_F1=F/Q1; bad_F2=-F/Q2
        rows.append(dict(W1=1.,W2=W,conservative_pair_force=F,
                         imposed_unweighted_F1=bad_F1,imposed_unweighted_F2=bad_F2,
                         imposed_unweighted_net_force=bad_F1+bad_F2,
                         residual_fraction_of_reference=float(abs(bad_F1+bad_F2)/F),
                         variational_force_sum=0.,same_field_passive_acceleration_ratio=W))
    return dict(rows=rows,scope='Fixed advected W, one instantaneous potential, no independent momentum-bearing medium. A new field can change this conclusion only with its dynamics included.')


def hot_shell() -> dict:
    # G=a=1, a cold unit-density-core-normalized sphere of total M=1 within r=1.
    # Hot thin shell M=10 at R=10; heat weight k=10. Scalar S uses full two-way geometry.
    R,Ms,k=10.,10.,10.
    rows=[]
    for r in (.01,.03,.1,.3,.7):
        gN=r
        scalar=Ms*k*np.log((R+r)/(R-r))/(2*R*r)
        quadS=Ms*k*.5*quad(lambda mu:1/(R*R+r*r-2*R*r*mu),-1,1,
                          epsabs=1e-12,epsrel=1e-12)[0]
        # Local divergence equation sees no additional source enclosed in this shell experiment.
        local=np.sqrt(gN)
        reference=np.sqrt(gN+scalar)
        rows.append(dict(r=r,core_newtonian=gN,hot_shell_scalar=scalar,quadrature_scalar=quadS,
                         weighted_source_extra_acceleration=local,
                         adopted_scalar_reference_extra_acceleration=reference,
                         enhancement_in_weighted_source=1.,
                         enhancement_in_adopted_scalar_reference=reference/local))
    return dict(shell=dict(radius=R,mass=Ms,heat_weight=k),rows=rows,
                quadrature_max_absolute_error=max(abs(r['hot_shell_scalar']-r['quadrature_scalar']) for r in rows),
                centre='Both exactly symmetric, shell-only vector forces vanish. The test compares the response to a cold central system at r>0.')


def cold_polarization() -> dict:
    """Static effective benchmark, not independent microscopic derivation.
    E = |gradPhi-P|^2/(8piG) + |P|^3/(12piG a).
    In spherical symmetry D=GM/r^2, P|P|/a=D, g=D+P.
    """
    masses=np.geomspace(1e-6,1e6,41)
    radii=np.geomspace(.1,1000,41)
    p=np.array([[brentq(lambda z:z*z-m/r**2,0.,2*np.sqrt(m)/r,
                       xtol=1e-14,rtol=1e-13) for r in radii] for m in masses])
    mslopes=[np.polyfit(np.log(masses),np.log(p[:,j]),1)[0] for j in range(len(radii))]
    rslopes=[-np.polyfit(np.log(radii),np.log(p[i]),1)[0] for i in range(len(masses))]
    # Solar-system issue: same parameters as adopted model, but no screening invented here.
    GMsun=1.32712440018e20
    solar=[]
    for name,dist in [('Earth',1.),('Saturn',9.58),('Neptune',30.1)]:
        gn=GMsun/(dist*AU)**2
        solar.append(dict(body=name,newtonian=gn,extra=np.sqrt(A_SI*gn),
                          fractional_extra=float(np.sqrt(A_SI/gn))))
    # Static single-potential action energy flux does not equal the auxiliary current.
    r=10.;M=1.;phi_grad=np.sqrt(M)/r
    aux=phi_grad**2  # dimensionless normalization of the outward auxiliary flux
    # Positive convex restoring energy implies P'(D)>=0. Exponential screen reverses P'(D).
    screen=[]
    for x in (.1,.5,1.,2.,10.):
        D=x*GD_SI
        extra=np.exp(-x)*np.sqrt(A_SI*D)
        derivative=extra*(.5/D-1/GD_SI)
        screen.append(dict(D_over_gd=x,extra=extra,dextra_dD=derivative))
    return dict(mass_exponent_min=float(min(mslopes)),mass_exponent_max=float(max(mslopes)),
                distance_exponent_min=float(min(rslopes)),distance_exponent_max=float(max(rslopes)),
                grid_size=len(masses)*len(radii),solar=solar,
                static_flux=dict(auxiliary_outward_flux=aux,noether_energy_flux=0.),
                screening_derivative=screen,
                scope='Numerical verification of an explicitly chosen cubic effective energy. No new exponent discovery and no screening success.')


def reservoir() -> dict:
    """Finite pumped store: supply counted as transfer from an explicit finite fuel pool.
    E'=p(Emax-E)-lambda E; F'=-p(Emax-E); R'=lambda E.
    No replenishment energy is created. Motion dependence of lambda remains an assumption.
    """
    p=65.6;Emax=1.;coldE=p/(p+1);coldP=coldE
    rows=[]
    for k in (0.,3.,12.,48.,100.,192.):
        lam=1+k
        def fun(t,y):
            supply=p*(Emax-y[0]);out=lam*y[0]
            return [supply-out,-supply,out]
        sol=solve_ivp(fun,[0.,.5],[coldE,1000.,0.],rtol=1e-10,atol=1e-11,
                      t_eval=np.linspace(0,.5,1001))
        y=sol.y
        pss=lam*p/(p+lam)
        rows.append(dict(k=k,steady_power_ratio=pss/coldP,
                         predicted_steady_ratio=(1+k)*(p+1)/(p+1+k),
                         terminal_power_ratio=lam*y[0,-1]/coldP,
                         energy_bookkeeping_max_abs=float(np.max(abs(y.sum(0)-(1000+coldE)))),
                         fuel_used=float(1000-y[1,-1])))
    age=13e9*YEAR
    return dict(pump_over_cold_leak=p,rows=rows,
                cold_rest_energy_fraction_13Gyr=ELL*age/C_SI**2,
                W193_rest_energy_fraction_13Gyr=193*ELL*age/C_SI**2,
                scope='A bounded toy supply and full energy ledger, not a derivation of a physical rest-energy conversion mechanism.')


class SpectralGravity:
    """Translation-invariant continuum Galerkin Hamiltonian in one periodic dimension.

    Fields phi, P and s. Matter couples ONLY to phi.
    Energy density (model units):
      .5(phi_x-P)^2 + [(P^2+eps^2)^(3/2)-eps^3]/[3(1+s^2)]
      + .5*kP*P_x^2 + .5*ks*s_x^2 + .5*ms^2*s^2 + lam*s^4/4.
    All kinetic energies positive. This specifies a conservative model, not the proposed q source.
    Phi's absent zero mode = a fixed, uniform compensating background, with no gradient force.
    The zero mode of s is present. Quadrature convergence of momentum is checked.
    """
    def __init__(self,n=5,ngrid=256):
        self.n=n; self.d=2*n;self.xg=2*np.pi*np.arange(ngrid)/ngrid
        self.k=np.repeat(np.arange(1,n+1),2)
        self.B=self.basis(self.xg);self.D=self.derivative(self.xg)
        self.Bs=np.column_stack([np.ones(ngrid),self.B]);self.Ds=np.column_stack([np.zeros(ngrid),self.D])
        self.R=np.zeros((self.d,self.d))
        for i,k in enumerate(range(1,n+1)):
            self.R[2*i,2*i+1]=k;self.R[2*i+1,2*i]=-k
        self.Rs=np.zeros((self.d+1,self.d+1));self.Rs[1:,1:]=self.R
        self.mass=np.array([.03,.04,.02])
        self.inertia=np.r_[np.ones(self.d),np.full(self.d,.7),np.full(self.d+1,1.2),self.mass]
        self.eps=.10;self.kp=.1;self.ks=.3;self.ms2=.6;self.lam=.4
    def basis(self,x):
        k=np.arange(1,self.n+1)
        t=np.outer(np.atleast_1d(x),k)
        a=np.empty((len(np.atleast_1d(x)),2*self.n))
        a[:,0::2]=np.sqrt(2)*np.cos(t);a[:,1::2]=np.sqrt(2)*np.sin(t)
        return a
    def derivative(self,x):
        k=np.arange(1,self.n+1);t=np.outer(np.atleast_1d(x),k)
        a=np.empty((len(np.atleast_1d(x)),2*self.n))
        a[:,0::2]=-np.sqrt(2)*k*np.sin(t);a[:,1::2]=np.sqrt(2)*k*np.cos(t)
        return a
    def split(self,q):
        d=self.d
        return q[:d],q[d:2*d],q[2*d:3*d+1],q[3*d+1:]
    def potential_gradient(self,q,energy=False):
        ph,pp,ss,x=self.split(q)
        pg=self.D@ph;P=self.B@pp;s=self.Bs@ss;px=self.D@pp;sx=self.Ds@ss
        diff=pg-P;root=np.sqrt(P*P+self.eps**2)
        cubic=(root**3-self.eps**3)/3
        amp=1+s*s
        Bx=self.basis(x)
        if energy:
            density=.5*diff**2+cubic/amp+.5*self.kp*px**2+.5*self.ks*sx**2+.5*self.ms2*s*s+self.lam*s**4/4
            return float(density.mean()+np.sum(self.mass*(Bx@ph)))
        dph=self.D.T@diff/len(pg)+Bx.T@self.mass
        dpp=(self.B.T@(-diff+P*root/amp)+self.kp*self.D.T@px)/len(pg)
        dss=(self.Bs.T@(-2*s*cubic/amp**2+self.ms2*s+self.lam*s**3)+self.ks*self.Ds.T@sx)/len(pg)
        dx=self.mass*(self.derivative(x)@ph)
        return np.r_[dph,dpp,dss,dx]
    def energy(self,q,p):
        return float(.5*np.sum(p*p/self.inertia)+self.potential_gradient(q,True))
    def momentum(self,q,p):
        ph,pp,ss,x=self.split(q);phm,pm,sm,mp=self.split(p)
        return float(np.sum(mp)-phm@(self.R@ph)-pm@(self.R@pp)-sm@(self.Rs@ss))
    def run(self,dt,T=8.):
        rng=np.random.default_rng(92026);d=self.d
        ph=rng.normal(0,.02,d)/(self.k**2)
        pp=rng.normal(0,.025,d)/(self.k**2)
        s=np.r_[.5,rng.normal(0,.025,d)/(self.k**2)]
        x=np.array([-.8,.6,2.])
        q=np.r_[ph,pp,s,x]
        p=rng.normal(0,.003,len(q));p[-3:]=self.mass*np.array([.12,-.07,.03])
        E0=self.energy(q,p);M0=self.momentum(q,p);de=dm=0.
        grad=self.potential_gradient(q)
        # Independent finite-difference check of the entire Hamiltonian force.
        err=0.
        for i in range(len(q)):
            h=1e-6; qp=q.copy();qm=q.copy();qp[i]+=h;qm[i]-=h
            fd=(self.potential_gradient(qp,True)-self.potential_gradient(qm,True))/(2*h)
            err=max(err,abs(fd-grad[i]))
        # Global translation invariance of field + matter, checked off-shell.
        z=.437
        from scipy.linalg import expm
        translated=np.r_[expm(-z*self.R)@ph,expm(-z*self.R)@pp,expm(-z*self.Rs)@s,x+z]
        trerr=abs(self.potential_gradient(translated,True)-self.potential_gradient(q,True))
        acceleration0=-grad[-3:]/self.mass
        expected=-self.derivative(x)@ph
        probe_error=float(np.max(abs(acceleration0-expected)))
        for j in range(round(T/dt)):
            p-=.5*dt*grad
            q+=dt*p/self.inertia
            grad=self.potential_gradient(q)
            p-=.5*dt*grad
            if j%20==0:
                de=max(de,abs(self.energy(q,p)-E0));dm=max(dm,abs(self.momentum(q,p)-M0))
        return dict(dt=dt,T=T,mode_count=self.n,quadrature_points=len(self.xg),
                    initial_energy=E0,max_relative_energy_error=de/max(abs(E0),1e-30),
                    max_absolute_momentum_error=dm,initial_momentum=M0,
                    force_finite_difference_max_absolute_error=err,
                    potential_global_translation_error=trerr,
                    universal_phi_acceleration_error=probe_error,
                    final_particle_positions=self.split(q)[-1].tolist(),
                    scope='1-D periodic coupled field/moving-particle conservation test. Not a 3-D galaxy, steady outflow, source heat derivation, or lensing test.')


def soft_mode_dispersion() -> dict:
    """Linearized longitudinal sector of the two-field gravity-only Hamiltonian.
    C=Aphi=1, AP=.7, KP=.1. p0 is the background |P| in a=1 units.
    Stable eigenvalues, using determinant/large-eigenvalue to avoid cancellation.
    Aphi phi_tt=div(grad phi-P); AP P_tt=grad phi-(1+2p0)P+KP lap P.
    At p0=0, omega_- ~ sqrt(KP/Aphi)*k^2 and vg/vphase -> 2.
    """
    C,AF,AP,KP=1.,1.,.7,.1
    ks=np.geomspace(1e-5,10.,800)
    rows=[]
    for p0 in (0.,1e-6,.01,1.,100.):
        a=C*ks**2/AF; d=(C*(1+2*p0)+KP*ks**2)/AP
        off2=C*C*ks**2/(AF*AP)
        big=.5*(a+d+np.sqrt((a-d)**2+4*off2))
        det=C*ks**2*(2*C*p0+KP*ks**2)/(AF*AP)
        small=det/big
        w=np.sqrt(small)
        z=np.gradient(np.log(w),np.log(ks))
        first=ks<1e-3
        rows.append(dict(background_P_over_a=p0,
                         infrared_frequency_exponent=float(np.polyfit(np.log(ks[first]),np.log(w[first]),1)[0]),
                         min_omega_squared=float(small.min()),
                         infrared_group_over_phase=float(np.median(z[first])),
                         infrared_sound_speed_squared=float(C/AF*(2*p0)/(1+2*p0)),
                         values=[dict(k=float(ks[i]),omega=float(w[i]),group_over_phase=float(z[i]))
                                 for i in (0,150,300,450,600,799)]))
    return dict(rows=rows,constants=dict(C=C,Aphi=AF,AP=AP,KP=KP),
                scope='Derived small-perturbation dispersion of the chosen effective action. No absolute physical speed is fitted or predicted.')


def anisotropy_check() -> dict:
    """Power-law Jeans control: rho ~ r^-alpha, g=vc^2/r, beta constant.
    sigma_r^2=vc^2/(alpha-2beta), trace_sigma=(3-2beta)*sigma_r^2.
    This is not a fit to X-COP.
    """
    rows=[]
    for alpha in (2.5,3.,3.5,4.):
        for beta in (.3,.5):
            ratio=((3-2*beta)/(alpha-2*beta))/(3/alpha)
            rows.append(dict(tracer_slope=alpha,beta=beta,
                             naive_multiplier_at_fixed_sigma_r=(3-2*beta)/3,
                             self_consistent_kinetic_trace_ratio=ratio))
    return dict(rows=rows,scope='Analytic power-law Jeans counterexample to multiplying heat by 3-2beta while keeping isotropic sigma_r fixed.')


def run() -> dict:
    t0=time.perf_counter()
    out=dict(repository_commit=COMMIT,environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
             constants=dict(a_SI=A_SI,gd_SI=GD_SI,u_SI=U_SI,ell_Wkg=ELL,
                            release_time_years=30000*AU/U_SI/YEAR))
    for key,fn in [('heat_filter',heat_filter),('nonlinear_response',nonlinear_polarization),
                   ('source_reciprocity',source_reciprocity),('hot_shell',hot_shell),
                   ('cold_polarization',cold_polarization),('reservoir',reservoir),
                   ('soft_mode_dispersion',soft_mode_dispersion),('anisotropy',anisotropy_check)]:
        out[key]=fn(); print('completed',key,flush=True)
    out['hamiltonian_dynamics']=[SpectralGravity().run(dt) for dt in (.002,.001)]
    out['hamiltonian_dynamics'].append(SpectralGravity(ngrid=512).run(.002))
    print('completed hamiltonian_dynamics',flush=True)
    # These assert numerical integrity, NOT scientific model acceptance.
    checks={
      'linear_covariance':out['heat_filter']['covariance_max_error']<1e-12,
      'monte_carlo_sampling':out['heat_filter']['max_abs_sampling_z']<5,
      'harmonic_time_integration':out['heat_filter']['harmonic_max_fractional_error']<1e-6,
      'shell_quadrature':out['hot_shell']['quadrature_max_absolute_error']<1e-9,
      'reservoir_bookkeeping':max(x['energy_bookkeeping_max_abs'] for x in out['reservoir']['rows'])<1e-7,
      'hamiltonian_force':max(x['force_finite_difference_max_absolute_error'] for x in out['hamiltonian_dynamics'])<1e-7,
      'hamiltonian_energy':max(x['max_relative_energy_error'] for x in out['hamiltonian_dynamics'])<1e-4,
      'hamiltonian_momentum':max(x['max_absolute_momentum_error'] for x in out['hamiltonian_dynamics'])<1e-7,
      'hamiltonian_translation':max(x['potential_global_translation_error'] for x in out['hamiltonian_dynamics'])<1e-10,
      'matter_phi_coupling':max(x['universal_phi_acceleration_error'] for x in out['hamiltonian_dynamics'])<1e-12,
    }
    out['numerical_integrity']={k:bool(v) for k,v in checks.items()}
    out['seconds']=time.perf_counter()-t0
    out['scope']='No dark-photon hypothesis. No new astronomical fit, no adoption of new gravity, no claim of complete theory.'
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    if args.output.exists():raise SystemExit('Refusing to overwrite existing results')
    ans=run();args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(ans,indent=2)+'\n')
    print(json.dumps(ans['numerical_integrity'],indent=2))
    if not all(ans['numerical_integrity'].values()):raise SystemExit(1)
