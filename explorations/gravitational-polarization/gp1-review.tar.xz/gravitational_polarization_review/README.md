# Gravitational polarization: independent construction and tests

Read **REPORT.md** for the full derivation, actual new results, assumptions and failures.

The package contains a gravity-only effective-model benchmark, not a finished gravitational theory. It introduces no dark-photon hypothesis and makes no new astronomical-fit claim. The latest repository evidence was read at round 21, commit `45f0a3ee04fdf0c6ca96ec8d10bb8195f488244b`.

## Files

- `REPORT.md`: technical report and primary/repository source references.
- `checks.py`: new self-contained, deterministic numerical tests.
- `results.json`: final results, environment and numerical-integrity checks.
- `STATUS.json`: explicit scientific claim status, including failures and untested requirements.
- `run.log`: final execution output.
- `supplied_audit/`: original user-supplied independent assessment, retained unchanged.
- `supplied_audit_reproduced.json`: its independently rerun output, identical to the supplied result.
- `MANIFEST.sha256`: file integrity manifest.

## Run

Requires Python with NumPy and SciPy. No internet or repository checkout is needed for these toy calculations.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python checks.py --output fresh_results.json
```

A fresh output path is required. The script refuses to overwrite existing results. Its ten numerical-integrity checks are not ten successes of the gravitational theory. The report separates the source-response diagnostic, 3D static radial algebra, 1D coupled dynamics, and dispersion analysis; those checks are not a single integrated galaxy experiment.

The final tests were repeated and every result except execution time reproduced exactly. No repository files, adopted constants or forecasts were changed.
