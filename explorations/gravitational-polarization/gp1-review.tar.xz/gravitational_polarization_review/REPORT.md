# Gravity-current and gravitational-polarization construction
## A derived consistency prototype, tested obstructions, and the unsolved physical closure

**Date:** 25 September 2026.  
**Repository read:** `lrspeiser/photon-graviton`, main at `45f0a3ee04fdf0c6ca96ec8d10bb8195f488244b` (round 21).  
**Scope:** New self-contained calculations; no dark-photon hypothesis; no new astronomical fit; no repository mutation. The prototype below is not the adopted hot-companion law and is not a completed explanation of cluster lensing.

## Executive result

I tested the latest proposed gravity-current / motion-polarization construction rather than assuming that its pieces can be combined. Three important problems appear:

1. Putting the motion factor directly in a single-potential source, `rho -> rho W`, also changes the passive force when the same action is varied. Keeping the old unweighted force instead leaves momentum unaccounted for. An independent gravitational state can carry the reaction, but it must actually be included.
2. A local divergence equation with the weighted source does not preserve the adopted law's hot-shell response. In spherical symmetry it counts enclosed weighted source, whereas the adopted scalar `S` includes exterior hot shells. This loses an important part of the proposed cluster mechanism.
3. The auxiliary current in the static variational construction is not automatically a physical energy flux. The Noether flux of the static potential is zero. The relation `a=2 ell/u` is consequently a calibration identity in the earlier proposal, not an independently derived microscopic prediction.

I then constructed a gravity-only, nonrelativistic polarization benchmark with actual gravitational fields and moving particles. Its force, field reaction and energy follow from one Hamiltonian. The unregularized static cold branch gives

\[
 g=\frac{GM}{r^2}+\frac{\sqrt{GMa}}{r}.
\]

A linearized branch of this chosen action is a genuine soft longitudinal mode: at vanishing background polarization, `omega ~ k^2`, and its group speed is twice its phase speed. The finite-dimensional moving-particle calculation conserves energy and momentum to the numerical accuracies below.

**These are consistency results, not a final gravitational solution.** The cubic restoring energy is still an effective-model choice; its cold reduction belongs to the nonlinear-Poisson/AQUAL class. I have not derived the independent microscopic origin demanded by the project, the source's heat-to-field transfer, the high-acceleration screening, or the relativistic lensing sector. The soft mode does not yet predict an absolute speed of 169.4 km/s. The separate successful checks must not be reported as one successful, fully integrated astrophysical experiment.

## 1. What was checked against the latest main

Round 21, rather than round 20, was current when this work began. The relevant new constraints are in the hot-companion technical README, section 32.

* In the faster crossing-heat comparison, changing the spreading speed to 600 km/s without adjusting energy density gives Bullet aperture masses 2.559 and 3.392 in units of `10^14 M_sun` on the finer grid. With the same emitted power and the necessary `u/v_h` dilution, the smaller half instead reaches 1.759. The repository reports that approximately 3.2-3.3 times the original crossing-heat power is needed to reach the lower target boundary. These are saved repository results, not new runs here.
* Its relativistic-action audit requires the radiation occupation and direction to be independent dynamical fields if they are to carry reaction, rather than position-dependent expressions varied without their own dynamics.
* The extra potential must enter the metric whose characteristics govern the relevant observed gravitational waves as well as the metric seen by light. Merely assigning a new matter-only potential is insufficient.
* The adopted law, constants and forecasts were not changed by that commit.

The supplied `soft_mode_assessment(1).zip` was unpacked and inspected. Its four listed manifest entries verified. Its independent source-audit script was rerun to a new file; the parsed result reproduced identically. Its distinction between specific leakage and luminosity remains valid. None of this is a rerun of the complete astronomical regression suite.

## 2. Correct signs and the precise role of the current

Use `g=-grad Phi` for the inward gravitational acceleration. An outward current is aligned with `+grad Phi`, not with `g`:

\[
 \mathbf J=\frac{u}{8\pi G}|\nabla\Phi|\nabla\Phi
          =-\frac{u}{8\pi G}|\mathbf g|\mathbf g.
\]

Thus `div J=ell rho W` corresponds to

\[
 \nabla\cdot(|\mathbf g|\mathbf g)=-4\pi G a\rho W,
 \qquad a=2\ell/u.
\]

The previous answer wrote the opposite current/acceleration sign in one place. Attraction requires the signs above.

Define `C=sqrt(8 pi G/u)`. The proposed static mixed functional is

\[
 I=\int d^3x\left[\frac{2C}{3}|\mathbf J|^{3/2}
             -\mathbf J\cdot\nabla\Phi-\ell\rho\Phi\right].
\]

Its variations correctly give `div J=ell rho` and `grad Phi=C sqrt(|J|) Jhat`. Eliminating `J`, and dividing by `ell` to give the usual energy-density units, gives

\[
 L_{\rm static}=-\int d^3x\left[
       \frac{|\nabla\Phi|^3}{12\pi G a}+\rho\Phi\right].
\]

This is a valid static effective action. It is also the deep nonlinear-Poisson MOND action, not a new physical derivation of the current's energy transport.

### Why the static current is not yet a streaming-energy law

For a simple dynamical extension,

\[
 \mathcal L=\frac{A_\Phi}{2}\dot\Phi^2-e(\nabla\Phi)-\rho\Phi,
 \quad e=\frac{|\nabla\Phi|^3}{12\pi G a},
\]

the field's local energy flux is

\[
 \mathbf S_\Phi=-\dot\Phi\,\frac{\partial e}{\partial\nabla\Phi}
              =-\frac{\dot\Phi}{\ell}\mathbf J.
\]

It vanishes when `dot Phi=0`, even though the auxiliary `J` is nonzero. A field can carry static stress and transmit force without continuously radiating energy. An actual nonequilibrium energy current requires additional dynamics, a physical source reservoir, and their own energy and momentum accounts.

Similarly, selecting the current exponent `3/2` because it produces the desired observational powers is inverse construction. It identifies the constitutive law to explain; it does not derive that exponent from an independently established physical mechanism.

## 3. Source weighting and universal falling: an exact obstruction

Suppose the proposed hot equation is

\[
 \nabla\cdot(|\nabla\Phi|\nabla\Phi)=4\pi Ga\rho W,
 \qquad W=1+\langle q^2\rangle.
\]

For particles with fixed, advected `W_i`, the matter term required by this one-potential action is

\[
 L_m=\sum_i\left[\frac12m_i v_i^2-m_iW_i\Phi(X_i)\right].
\]

Varying `X_i` then gives

\[
 \ddot X_i=-W_i\nabla\Phi(X_i).
\]

The same weight appears in active sourcing and passive acceleration. If `W` depends on velocity, position or evolving internal state, its derivatives introduce additional terms; they do not disappear.

The static field stress also makes the issue explicit. With

\[
 \Pi_{ij}=\frac{1}{4\pi Ga}
       (|g|g_i g_j-\tfrac13|g|^3\delta_{ij}),
\]

the weighted field equation gives `partial_j Pi_ij=-rho W g_i`. Matter assigned force density `rho g_i` does not balance that stress unless `W=1` or another dynamical sector supplies the difference.

A two-body diagnostic makes the mismatch large, not a rounding error. I used the known deep nonlinear-gravity two-body relation only as a mathematical control, with active charges `Q_i=m_i W_i`. For equal inertial masses and `W_1=1`, `W_2=68`, a conservative charge-coupled calculation gives equal and opposite forces. Replacing each force by its unweighted `m_i g_i` counterpart leaves a resultant equal to `1-1/68=0.985294` of the reference pair force. This is not a general impossibility theorem for dynamical gravitational fields; it rejects the instantaneous one-potential shortcut.

**Repair principle:** retain ordinary matter's universal coupling to the physical metric/potential. Put the additional state, its energy and its reaction in the gravitational sector. Do not silently attach a large state-dependent gravitational charge to each baryon and keep its inertia and passive coupling unchanged.

## 4. What the q equation really proves

Retain the proposed equation as a clearly specified, conditional response model:

\[
 \dot{\mathbf q}=-\gamma\mathbf q+\frac{\gamma}{u}\mathbf w(t),
 \qquad \mathbf w=\mathbf v-\mathbf U.
\]

For any stationary zero-mean velocity process, let

\[
 C_w(t)=\langle\mathbf w(t)\cdot\mathbf w(0)\rangle.
\]

Solving the filter and performing its two-time average gives

\[
 \boxed{\langle q^2\rangle=
       \frac{\gamma}{u^2}\int_0^\infty e^{-\gamma t}C_w(t)\,dt.}
\]

If `C_w(t)=3 sigma^2 exp(-nu t)`, this becomes

\[
 \langle q^2\rangle=\frac{3\sigma^2}{u^2}\frac{\gamma}{\gamma+\nu}.
\]

The numerical checks solve the corresponding stationary covariance equation independently and sample 50,000 independent three-dimensional states at each of seven correlation rates. Separate time-domain integrations verify sinusoidal forcing. These confirm the mathematics of the assumed filter, not that gravitational matter has this response.

### The important extension: orbital and gyromotion correlations

If a velocity component decorrelates while rotating,

\[
 C_w(t)=3\sigma^2e^{-\nu t}\cos\Omega t,
\]

then

\[
 \boxed{\langle q^2\rangle=\frac{3\sigma^2}{u^2}
  \frac{\gamma(\gamma+\nu)}{(\gamma+\nu)^2+\Omega^2}.}
\]

Thus the state depends on the velocity spectrum, not on dispersion alone. Ordered motion is not automatically excluded unless `U` is a physical, dynamically defined local flow. An imposed classification by galaxy name or object type is not a derivation.

For a magnetized distribution with two gyrating components and one non-gyrating parallel component,

\[
 \langle q^2\rangle=\frac{\sigma^2}{u^2}\left[
 \frac{\gamma}{\gamma+\nu}+
 \frac{2\gamma(\gamma+\nu)}{(\gamma+\nu)^2+\Omega^2}\right].
\]

When `Omega >> gamma` and parallel decorrelation is slow, one third of the unfiltered isotropic heat remains. Gyromotion alone therefore does not prove that gas is cold in this mechanism. Actual parallel transport and decorrelation rates must be measured or calculated. No specific cluster-plasma correlation rate was assumed or fitted here.

The relaxation energy is not free either. With an illustrative `E_q=C_q q^2/2`,

\[
 \dot E_q=-C_q\gamma q^2+C_q\gamma\mathbf q\cdot\mathbf w/u.
\]

The second term is work supplied by the drive and the first is transfer to a dissipative sector. Prescribed velocity histories or a stochastic thermostat do not close the mechanical ledger. The new Hamiltonian test below does not yet generate this q filter.

## 5. The claimed saturation is not saturation

The last proposal used

\[
 \dot q=-\gamma(1+q^2/q_s^2)q+\gamma w/u.
\]

For a steady aligned drive, `q+q^3/q_s^2=w/u`. At large drive,

\[
 q\sim(q_s^2 w/u)^{1/3},\qquad q^2\propto w^{2/3}.
\]

It grows without bound. The numerical high-speed exponent is 0.66715, consistent with the analytical `2/3`, not zero.

Using the earlier illustrative `q_s^2=65.6`, Maxwell-distribution quadrature gives:

| Unfiltered k | Cubic-damping heat | Separately postulated bounded-response heat |
|---:|---:|---:|
| 3 | 2.6550 | 2.6327 |
| 12 | 8.5199 | 8.0919 |
| 48 | 22.6417 | 18.8525 |
| 100 | 35.2575 | 26.1085 |
| 192 | 50.4000 | 32.7333 |
| 10,000 | 282.9254 | 58.8322 |
| 100,000,000 | 6956.7714 | 65.5266 |

The bounded control uses `qdot=-gamma q+gamma(w/u)(1-q^2/q_s^2)`; its invariant ball is `|q|<=q_s`. It is a different hypothesis, not a derived repair. Neither choice has been inserted into the astronomical law in this work.

### A finite replenished source can be energy-consistent

A separate source test uses

\[
 \dot E=r(E_{\max}-E)-\lambda E,\quad
 \dot F=-r(E_{\max}-E),\quad
 \dot E_{out}=\lambda E.
\]

Here `F` is an explicitly counted finite fuel store. Therefore `E+F+E_out` is conserved. With `lambda=lambda_0(1+k)` and `p=r/lambda_0`,

\[
 \frac{P_{ss}(k)}{P_{ss}(0)}=
       \frac{(1+k)(p+1)}{p+1+k}.
\]

This produces genuine saturation of steady luminosity. With the illustrative `p=65.6`, the ratio is 40.376 at `k=100`, rather than 101. The energy ledger closes to better than `6e-13` model-energy units in the computed intervals.

The physical origin of that replenishment remains missing. The fitted gravitational emissivity integrated for 13 billion years corresponds to approximately `2.44e-5` of rest energy at the cold rate, or `0.00470` at a continuously maintained factor 193. These are budget calculations, not evidence for an available conversion process. If the specified heat power were instead drawn solely from random kinetic energy, the old `u/a ~ 85 Myr` drain remains applicable to that continuous-emission assumption.

## 6. Hot-shell test: why the weighted source loses the cluster mechanism

For a spherical local source equation,

\[
 g_c^2(r)=\frac{Ga}{r^2}\int_0^r4\pi s^2\rho(s)W(s)\,ds.
\]

An exterior hot shell does not change this field inside. By contrast, the adopted model contains the unsigned two-way quantity

\[
 S(r)=G\int\frac{k\rho(x')}{|x-x'|^2}\,d^3x'.
\]

For a thin hot shell of radius `R`, mass `M_s`, and heat weight `k`, at `0<r<R`,

\[
 S_{shell}(r)=\frac{GM_s k}{2Rr}\ln\frac{R+r}{R-r}.
\]

It tends to `GM_s k/R^2`, not zero, near the centre. The shell alone has no preferred vector force at its exact centre; the diagnostic is how it changes the response to a weak central system.

The test uses `G=a=1`, a cold central sphere of radius 1 and mass 1, plus a hot shell `R=10, M_s=10, k=10`. At `r=0.1`, the central Newtonian acceleration is 0.1. The local weighted-source law gives companion acceleration 0.31623 both with and without the shell. The adopted scalar-S prescription gives 1.04882 with the shell, versus 0.31623 without it: an enhancement of 3.31668. Direct angular quadrature verifies the shell integral to `3.7e-14` absolute accuracy.

This is a decisive counterexample to treating the proposed weighted-source equation as a microscopic derivation of the already-fitted cluster law. It does not rule out an independent gravitational state whose local susceptibility is changed by energy arriving from an exterior shell.

## 7. A gravity-only consistency prototype with real field dynamics

To implement that repair principle, use gravitational variables:

* `Phi`: the scalar potential appearing in ordinary matter's force;
* `P`: an independent gravitational-polarization vector, with acceleration units;
* `s`: a dimensionless gravitational response state, not an added particle number or free halo mass.

These are proposed extra gravitational degrees of freedom, not experimentally identified constituents. Calling them gravitational rather than photonic does not establish their existence.

Define

\[
 \mathbf D=\nabla\Phi-\mathbf P,
\]

and an effective field energy

\[
 \mathcal E=
 \frac{|\mathbf D|^2}{8\pi G}
 +\frac{|\mathbf P|^3}{12\pi Ga\,\mathcal A(s)}
 +\frac{K_P}{2}|\nabla\mathbf P|^2
 +\frac{K_s}{2}|\nabla s|^2+V(s),
 \qquad \mathcal A(s)=1+s^2.
\]

Use positive kinetic coefficients:

\[
 \mathcal L_g=
 \frac{A_\Phi}{2}\dot\Phi^2+
 \frac{A_P}{2}|\dot{\mathbf P}|^2+
 \frac{A_s}{2}\dot s^2-\mathcal E,
\]

with ordinary matter

\[
 L_m=\sum_i[\tfrac12m_i v_i^2-m_i\Phi(X_i)].
\]

The scalar state is a test of where an additional response can consistently live. It is **not** identified with the independently computed q variance, and its matter-driven production is not yet derived. `A(s)`, the cubic power, and the dynamical coefficients are effective-model assumptions. This prototype introduces additional coefficients; it is not the original four-constant fit.

### Equations from this one action

\[
 A_\Phi\ddot\Phi=\frac{1}{4\pi G}\nabla\cdot\mathbf D-\rho,
\]

\[
 A_P\ddot{\mathbf P}=\frac{\mathbf D}{4\pi G}
 -\frac{|\mathbf P|\mathbf P}{4\pi Ga\mathcal A(s)}+K_P\nabla^2\mathbf P,
\]

\[
 A_s\ddot s=K_s\nabla^2s-V'(s)
 +\frac{|\mathbf P|^3\mathcal A'(s)}{12\pi Ga\mathcal A(s)^2},
\]

\[
 \boxed{\ddot X_i=-\nabla\Phi(X_i).}
\]

The force is now the derivative of the same Hamiltonian that evolves the gravitational degrees of freedom. It is not a square root assigned to a source-output table. A gradient potential also fixes the longitudinal character of the matter acceleration without a separate Helmholtz projection.

### Static cold branch

For `s=0`, negligible P-gradient term, and stationary fields,

\[
 \nabla\cdot\mathbf D=4\pi G\rho,
 \qquad\mathbf D=|\mathbf P|\mathbf P/a.
\]

Outside a spherical source,

\[
 D=GM/r^2,\quad P=\sqrt{aD},\quad
 |\nabla\Phi|=D+P=GM/r^2+\sqrt{GMa}/r.
\]

Numerical root-solving over 1,681 independent mass-radius pairs verifies companion exponents 0.5000000000 and 1.0000000000 to approximately `1.5e-12`. This is a numerical check of the chosen equations, not an independent discovery of the exponents.

If the uniform state is externally held at another value, this algebra gives `P=sqrt[a A(s)D]`. The coupled equations, however, must determine `s`; externally selecting it is not a heat-source derivation.

### Momentum and energy

For the complete continuum fields, the canonical total momentum has the form

\[
 \mathbf P_{tot}=\sum_i m_i\mathbf v_i-
 \int d^3x\,[A_\Phi\dot\Phi\nabla\Phi+
 A_P\dot P_j\nabla P_j+A_s\dot s\nabla s].
\]

Translation invariance gives its conservation with the stated boundary conditions. The field energy flux is

\[
 \mathbf S=-\frac{\dot\Phi\mathbf D}{4\pi G}
            -K_P\dot P_j\nabla P_j-K_s\dot s\nabla s.
\]

The field-energy exchange is `-rho dot Phi`; adding ordinary matter's mechanical and interaction energy closes the total account. Static fields again have static stress but no radiative flux.

### Actual numerical coupled-field / moving-particle calculation

The implemented test is one-dimensional and periodic: five Fourier harmonics for Phi and P, plus a zero mode and five harmonics for s, and three moving particles. Phi has zero spatial mean; this is equivalent to a uniform compensating background for the periodic source. The nonlinearity is smoothed only for this numerical test using

`[(P^2+epsilon^2)^(3/2)-epsilon^3]/3`, with `epsilon=0.1`.

The s potential is `V(s)=0.6 s^2/2+0.4 s^4/4`; the gradient coefficients are `K_P=0.1`, `K_s=0.3`; kinetic coefficients are `1,0.7,1.2`. These are model units, not calibrated astrophysical numbers. The initial s state and field excitations are specified initial data, not claimed to arise from the required matter heat mechanism.

| Test | Measured result |
|---|---:|
| Maximum relative total-energy error, dt=0.002 | 9.315e-7 |
| Maximum relative total-energy error, dt=0.001 | 2.329e-7 |
| Error reduction upon halving dt | approximately 4 |
| Maximum absolute total-momentum drift, 256-point quadrature | less than 4.6e-15 |
| Maximum absolute total-momentum drift, 512-point quadrature | 1.3e-16 |
| Hamiltonian gradient versus independent energy finite differences | less than 1.3e-11 |
| Potential energy under simultaneous translation of particles and fields | less than 1.4e-17 |
| Matter acceleration versus minus the local Phi gradient | less than 1.8e-18 |

This demonstrates conservation and a common bare test-particle coupling in a finite, explicitly defined dynamical model. It is not a 3-D force-law simulation, a composite-body equivalence-principle test, a relativistic stability proof, a sustained outflow, or an astronomical fit. Timestep and quadrature convergence were tested; a complete continuum/spatial-mode convergence study was not performed.

## 8. A genuine gravity-only soft mode emerges in this benchmark

Linearize the unregularized cold Phi-P sector around a homogeneous polarization magnitude `P_0`; take the wavevector parallel to it for the longitudinal mode. Set `C=1/(4 pi G)` and `b=P_0/a`. Its frequency-squared matrix after kinetic normalization has diagonal entries

\[
 A=Ck^2/A_\Phi,
 \qquad D=[C(1+2b)+K_P k^2]/A_P,
\]

and squared off-diagonal magnitude

\[
 |B|^2=C^2k^2/(A_\Phi A_P).
\]

The two eigenfrequencies obey

\[
 \omega_\pm^2=\tfrac12[A+D\pm\sqrt{(A-D)^2+4|B|^2}].
\]

Their determinant is

\[
 \omega_+^2\omega_-^2=
 \frac{Ck^2(2Cb+K_P k^2)}{A_\Phi A_P}\ge0.
\]

For `P_0=0`, the lower branch is

\[
 \boxed{\omega_-^2\simeq (K_P/A_\Phi)k^4.}
\]

Thus `omega ~ k^2`, `v_phase ~ k` and `v_group ~ 2k`:

\[
 \boxed{v_{group}/v_{phase}\rightarrow2.}
\]

The numerical logarithmic frequency exponent is 1.999999956 in the infrared; the corresponding group-to-phase ratio is 1.999999992. This is derived from the model's positive quadratic dynamics, not assigned by calling something a slow photon. The two fields co-adjust so that their leading gradient energy nearly cancels; the P-gradient stiffness then supplies the surviving `k^4` restoring term.

At nonzero background polarization the infrared mode instead becomes acoustic:

\[
 c_{soft}^2=\frac{C}{A_\Phi}\frac{2b}{1+2b}.
\]

Consequently its speed depends on background and wavelength. It does not yet provide the project's universal 169.4 km/s, and it cannot be used to assert a Cherenkov exemption. The other scalar state and transverse polarizations need their own characteristic analysis. This is not the observed tensor gravitational-wave channel.

## 9. Why this still does not meet the final-solution standard

### 9.1 The cubic root has not been independently derived

The effective restoring energy `|P|^3` gives the desired mass and radius powers. Replacing the power by `n` produces `P ~ D^(1/(n-1))`, so the target selects `n=3`. This identifies a microscopic requirement; it does not establish its cause. Isotropy alone does not select a nonanalytic cubic norm.

Eliminating the algebraic polarization in the static cold branch produces an AQUAL-type nonlinear-Poisson theory. Gravitational-polarization interpretations and auxiliary-field formulations of MOND already exist. The model cannot be advertised as a new root merely because its variables have different names. The independent dynamic state could make the full theory different, but only after its ordinary-matter sourcing and predicted hot-system behavior are established.

The earlier universal claim that equilibrium media cannot produce the exponents was too broad. The specific gapped scalar/positive-quartic experiments in round 20 fail; the present effective nonlinear-polarization action is a counterexample to that broader assertion. It is not a derivation of the project's nonequilibrium transport mechanism.

### 9.2 The high-acceleration regime is wrong without an additional mechanism

The unscreened branch predicts extra solar acceleration fractions of approximately `1.03e-4` at Earth, `9.87e-4` at Saturn and `3.10e-3` at Neptune. These fail the repository's requirement that the companion be negligible there. No screening factor was inserted to hide this.

There is a useful restriction on a simple repair. In a convex local restoring model `D=V'(P)`, P increases with D. The adopted exponential extra acceleration

\[
 P(D)=e^{-D/g_d}\sqrt{aD}
\]

has

\[
 dP/dD=P(1/(2D)-1/g_d)<0\quad\text{for }D>g_d/2.
\]

A monotone convex restoring potential alone cannot supply that complete rise-and-fall curve. A field-dependent coupling, additional state, or another screening mechanism is needed. An inverse-fitted interpolation would reproduce the desired force but would not establish its origin.

### 9.3 Cluster lensing has not been inherited

The hot-shell counterexample shows that even one seemingly minor change of field equation loses a crucial part of the old cluster law. The new prototype has not been evaluated against X-COP, Bullet, KiDS, dwarfs, or the frozen velocity-dispersion lensing prediction. It inherits none of the old suite's success counts.

Round 21 requires increased post-collision power for Bullet, while round 20's self-consistent relaxed-cluster calculation already overshoots outer gravity. A universal suppression or saturation alone cannot be declared to solve both. A correct new state needs history and spatial transport, not merely a global multiplier.

There is also a caution on the earlier anisotropy suggestion. For `rho_star ~ r^-alpha`, `g=v_c^2/r`, and constant beta, the self-consistent Jeans solution is

\[
 \sigma_r^2=v_c^2/(\alpha-2\beta),\quad
 \langle v^2\rangle=(3-2\beta)v_c^2/(\alpha-2\beta).
\]

At `alpha=3`, changing beta does not change this total kinetic trace at all. Multiplying an unchanged isotropic dispersion by `3-2 beta` is not a self-consistent anisotropic calculation. The supplied code verifies this control; it is not a cluster fit.

### 9.4 The relativistic metric and radiation constraints remain open

A nonrelativistic scalar potential determines slow-body acceleration, not both weak-field metric potentials. With

\[
 ds^2=-(1+2\Phi/c^2)c^2dt^2+(1-2\Psi/c^2)d\mathbf x^2,
\]

lensing depends on the transverse gradient of `Phi+Psi`, whereas slow motion depends primarily on Phi. Neither `Psi=Phi` nor the required light deflection can be adopted without deriving the physical metric equations.

A viable completion must specify one physical metric for ordinary matter and electromagnetism, obtain the gravitational-state stress by variation, and check tensor propagation, extra-mode radiation, high-energy losses, weak/strong equivalence behavior, stability and initial data. GW170817 constrains the observed tensor-wave/light comparison; it does not by itself exclude every additional collective mode. Conversely, calling a mode soft or assigning a relaxation time does not demonstrate its safety.

## 10. What is actually established, and what must not be claimed

**Established in these calculations:** the conditional q-response kernel and its frequency dependence; the failure of the claimed cubic saturation; the source/passive-coupling obstruction; the loss of the hot-shell response; a gravity-only effective Hamiltonian with explicit moving matter and conserved energy/momentum; its cold radial scaling in the stated static limit; a soft longitudinal branch and its infrared dispersion; and a finite-source replenishment ledger.

**Not established:** an independent microphysical derivation of the cubic gravitational energy; an observed new gravitational state; the motion-to-state production in the same Hamiltonian; the required steady outward luminosity; the common value of u; consistent screening; cluster/dwarf/lensing fits for the new equations; a relativistic completion; or a final solution to gravity.

The research direction should therefore be defined more precisely:

> Ordinary matter must excite an independent gravitational response state. That state modifies the gravitational field's stress or susceptibility, rather than changing each body's passive gravitational charge. Its source, propagation, damping, screening and metric coupling must be calculated as one system.

The present GP-1 benchmark is an executable place to test that statement, not an adopted theory. No repository files, constants, forecasts or baseline scores were changed.

## 11. Reproduction

Requirements: Python, NumPy and SciPy. The development environment versions are recorded in results.json. No network access, proprietary data, or repository checkout is required for the new toy checks.

```
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python checks.py --output new_results.json
```

The script refuses to overwrite an existing output. The ten `numerical_integrity` booleans check implementation quality, **not whether the proposed gravitational theory is correct**. The deterministic numerical results were rerun; the execution-time field is not expected to reproduce byte for byte.

The independent uploaded audit can be rerun using its included script and a fresh output path. It reproduces its supplied JSON exactly in this environment.

## 12. Source provenance and primary references

Repository evidence, read through the connected GitHub tool:

* Main at `45f0a3ee04fdf0c6ca96ec8d10bb8195f488244b`; branch metadata and hot-companion README sections 32.1-32.5.
* https://github.com/lrspeiser/photon-graviton/blob/45f0a3ee04fdf0c6ca96ec8d10bb8195f488244b/research_work/results/hot-companion/README.md
* Earlier source constants and the two-way scalar shell law are as quoted in the supplied conversation/repository records. This work did not reread every historical file or rerun the full suite.

User-supplied evidence:

* `Pasted markdown(20260925-173602).md`, the soft-mode assessment, especially its force/source distinction, finite-store audit and screening caveat.
* `soft_mode_assessment(1).zip`, independently manifest-checked and reproduced. Its original files are preserved in the package.

Primary literature used as controls, not as a claimed independent root:

* Milgrom, "Quasi-linear formulation of MOND," MNRAS 403 (2010), arXiv:0911.5464. Sections I and II describe the nonlinear-Poisson action, conservation laws and auxiliary-field reformulations; equality in spherical symmetry does not make all nonspherical constructions identical. https://arxiv.org/html/0911.5464v2
* Milgrom, "General virial theorem for modified-gravity MOND," Phys. Rev. D 89, 024016 (2014), arXiv:1311.2579. Source of the known two-body control relation, not a new force law found here. https://arxiv.org/abs/1311.2579
* Blanchet and Marsat, "Modified gravity approach based on a preferred time foliation," Phys. Rev. D 84, 044056 (2011), arXiv:1107.5264. A primary example showing that extra gravitational fields and lensing completions require explicit relativistic structure and overlap existing MOND-related work. https://arxiv.org/html/1107.5264v1
* Touboul et al., "MICROSCOPE mission: final results of the test of the Equivalence Principle," Phys. Rev. Lett. 129, 121102 (2022), arXiv:2209.15487. Laboratory test-body universality is an important constraint; no direct application of that bound to unscreened cluster populations is claimed. https://arxiv.org/abs/2209.15487
* LIGO/Virgo/Fermi/INTEGRAL, "Gravitational Waves and Gamma-rays from a Binary Neutron Star Merger: GW170817 and GRB 170817A," ApJL 848 L13 (2017), arXiv:1710.05834. https://arxiv.org/abs/1710.05834
* Moore and Nelson, "Lower Bound on the Propagation Speed of Gravity from Gravitational Cherenkov Radiation," JHEP 09 (2001) 023, arXiv:hep-ph/0106220. Extra-mode loss rates must be computed for the actual coupling/dispersion, rather than presumed safe. https://arxiv.org/abs/hep-ph/0106220
